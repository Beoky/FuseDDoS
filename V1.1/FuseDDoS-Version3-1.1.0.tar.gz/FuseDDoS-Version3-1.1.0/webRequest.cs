﻿using System;

namespace DDoSAttack_For_Windows_NET_4._6._1
{
    internal class webRequest
    {
        public static implicit operator webRequest(string v)
        {
            throw new NotImplementedException();
        }
    }
}