# FuseDDoS-Version-3
FuseDDoS Version 3 with C#! and Best of Testing Flood Layer 4!
# What you need?
* NET FRAMEWORK 4.6.1 (trying to ask in issues for downgrade net)
# Overview
![Over1](https://raw.githubusercontent.com/PC1266/FuseDDoS-Version3/main/rererererere.PNG)
# About with Version 2 and 1
FuseDDoS Version 2 and 1 Created for Edu and testing server
but Version 2 and 1 is not good sending and LOW rate to sending!
# Code to create this
FuseDDoS Version 3 Creating from C# are good rate code and going to support with other OS!
So version 2 and 1 is using batch to creating,
# Open Source
FuseDDoS Version 3 are open source and free edit~
# Terms of Services
So this will very illgeal to attack other server if you not are owner or have any permission, or read Q&A 
# How to working?
FuseDDoS version 3 will send unicode to overheat any server!
![HOW THAT WORK?](https://media.discordapp.net/attachments/879939876181647380/911838523114528858/howwork.png?width=867&height=434)
# Patch and News!
Format: dd/mm/yyyy
* 2/12/2021 - FuseDDoS Version 3 (Release v1.3.0) *Read more in Release.*
* 25/11/2021 - FuseDDoS Version 3 (Release v1.2) *Read more in Release.*
* 22/11/2021 - FuseDDoS Version 3 (Beta v1.1) *Read More in Release.*
* 21/11/2021 - FuseDDoS Version 3 (Beta v1.0) *Read More in Release.*
* 20/11/2021 - FuseDDoS Version 3 (Beta v0.7) *Read More in Release.*
# Methods
Now have just 4
* Flooding UDP
* Slow-Rate-Attack UDP
* SYN Flooding TCP
* HTTP flooding HTTP [not done]
# What in new Methods in soon?
* HTTP Flooding
* HTTP Proxy Attacking.
* Bigspammer Proxy!
# Tips!
* 1 window = 10-20K req still try 2-3 window for 40-60K req
# Q&A
* Q: Why not having to having select proctool?
* A: We using DNS that are support with TCP and UDP!
* Q: i trying attack but server not down what happends?
* A: Look a reason this!
* Making to sure you have a good pc or server spec.
* Some version maybe having problem try downgrade a version! if work please contect in issues bar to fix it!
* ISP maybe block many packets from you pc
* Really in task manager maybe show 500 mbps - 1Gbps but server will get 100-300 MBPS From limited Package of you internet ISP!
* If ISP you is good maybe you Wifi are problem! 2.4GHz is bad for it (Recommends to using 5Ghz or lan!)
* If you are pro of C# you can edit for free! from Fork github or Download! (If editing is working please ask in issues bar to update with new version!)
* Q: (Law asking time!) What happends if i ddosing a server without allowed?
* A: This will happends!
* If you attacked on big server there no way to get attacked!
* If you attacked and making owner or he or her lost money and customer owner/he/her will asking in law and asking police for it.
* 80% owner program ddos will not asking in law if him write tos in program!
* After you get email/SMS/Call/Paper about this you need asking owner/he/her in online or police station.
* If lucky. owner/he/her is okay to agree it you maybe not get bad history on profile. or maybe get!
* If unlucky owner/he/her will using law to you are prsion! (Computer law.) (1 month to 10 year) (Fine 1000$ - 100000$ up to lost in bussines)
* If lucky after you quit from jail you maybe agreed to playing computer!
* But if unlucky you maybe cannot using internet or computer (can but very limited) if you need to using you need wait 1 - 5 year!
* Q: how i did ask a issues
* A: click a issues bar and report we!
# History about Destory Server of Version 3.
* MCTHAM on 12:19 PM (Time in Thailand) play.mctham.xyz having networking issuses after get attacked (Methods big spammer) (Reason: Server is cannot read bigger chinese language.)
![mctham](https://media.discordapp.net/attachments/827390907502034995/911856265989337098/unknown.png?width=772&height=434)


