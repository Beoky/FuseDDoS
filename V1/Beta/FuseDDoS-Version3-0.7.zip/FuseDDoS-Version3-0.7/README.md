# FuseDDoS-Version-3
FuseDDoS Version 3 with C#!
# What you need?
* NET FRAMEWORK 4.6.1 (trying to ask in issues for downgrade net)
# Overview
![Over1](https://media.discordapp.net/attachments/879939876181647380/911925550115852328/unknown.png)
# About with Version 2 and 1
FuseDDoS Version 2 and 1 Created for Edu and testing server
but Version 2 and 1 is not good sending and LOW rate to sending!
# Coding
FuseDDoS Version 3 Creating from C# are good rate code and going to support with other OS!
So version 2 and 1 is using batch to creating,
# Open Soucre
FuseDDoS Version 3 are Open Soucre and free edit~
# Terms of Services
So this will very illgeal to attack other server if you not are owner or have pem,
# How to working?
FuseDDoS version 3 will send CHINA lang to overheat any server!
![HOW THAT WORK?](https://media.discordapp.net/attachments/879939876181647380/911838523114528858/howwork.png?width=867&height=434)
# Patch and News!
* 20/11/2021 - FuseDDoS Version 3 (Beta v0.7) *Read More in Release.*
# Methods
Now have just 2
* Big Spammer
* Big Flooded
Plz wait to newer
# Q&A
* why not having to select proctool?
* A: We using DNS that are support with TCP and UDP!
* Ask more in Issuses!
# History about Destory Server of Version 3.
* MCTHAM on 12:19 PM (Time in Thailand) play.mctham.xyz having networking issuses after get attacked (Methods big spammer) (Reason: Server is cannot read bigger chinese language.)
![mctham](https://media.discordapp.net/attachments/827390907502034995/911856265989337098/unknown.png?width=772&height=434)


